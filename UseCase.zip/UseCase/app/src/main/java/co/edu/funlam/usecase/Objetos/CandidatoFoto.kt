package co.edu.funlam.usecase.Objetos

import co.edu.funlam.usecase.Objetos.Candidato

class CandidatoFoto (nombre: String, partido: String, Tarjeton: Int, val foto: Int): Candidato(nombre, partido, Tarjeton) {


}